package org.uma.mbd.mdGenetico.genetico;

public class CeroMax implements Problema {

    @Override
    public double evalua(Cromosoma dato) {
        double salida= 0;


        for(int i=0;i<(dato.longitud());i++){
            salida = salida+dato.gen(i);
        }

        return salida;
    }
}
