package org.uma.mbd.mdGenetico.genetico;

public class OneMax implements Problema {

	/**
	 * El fitness de un individuo es el número de unos que tiene el cromosoma.
	 * @see Problema#evalua(Cromosoma)
	 */
	@Override
	public double evalua(Cromosoma dato) {
		double salida= 0;


		for(int i=0;i<(dato.longitud());i++){
			salida = salida+dato.gen(i);
		}

		return salida;
	}
}
