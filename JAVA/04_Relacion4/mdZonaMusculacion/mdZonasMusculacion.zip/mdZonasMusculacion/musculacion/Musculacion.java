package org.uma.mbd.mdZonasMusculacion.musculacion;


import com.opencsv.CSVReader;

import java.io.*;
import java.net.URL;
import java.util.*;

public class Musculacion {
    private final static int MAQUINA_ID = 18;
    private final static int MAQUINA_NOMBRE = 19;
    private final static int MAQUINA_URL_ICON = 21;
    private final static int MAQUINA_NIVEL = 20;
    private final static int MAQUINA_FUNCION = 22;
    private final static int MAQUINA_DESCRIPCION = 23;
    private final static int ZONA_ID = 14;
    private final static int ZONA_NOMBRE = 15;
    private final static int ZONA_URL_ICON = 17;
    private final static int ZONA_UBICACION = 2;

    // COMPLETAR EL ESTADO


    public Musculacion(String ciudad) {
        // COMPLETAR
    }

    public String getCiudad() {
        // COMPLETAR
        return null;
    }

    public void leeDatosLocal(String ficheroCSV) throws IOException {
        try (InputStream in = new FileInputStream(ficheroCSV);
             InputStreamReader isr = new InputStreamReader(in);
             BufferedReader bin = new BufferedReader(isr);
             CSVReader reader = new CSVReader(bin)) {
            leeDatos(reader);
        }
    }

    public void leeDatosUrl(String urlCSV) throws IOException {
        URL url = new URL(urlCSV);
        try (InputStream in = url.openStream();
             InputStreamReader isr = new InputStreamReader(in);
             BufferedReader bin = new BufferedReader(isr);
             CSVReader reader = new CSVReader(bin)) {
            leeDatos(reader);
        }
    }

    private void leeDatos(CSVReader reader) throws IOException {
        reader.readNext(); // Ignoramos la primera linea
        List<String[]> datos = reader.readAll();  // Se leen todos los datos en un array
        // El resultado es una lista de arrays.
        // Cada array contiene todos los tokens de una linea

        for(String[] tokens : datos) { // Foreach por cada array de tokens
            // Leemos los datos que nos interesan de la maquina

            // COMPLETAR

            // leemos el identificador de la zona
            int zonaId = Integer.parseInt(tokens[ZONA_ID]);
            // Se debe ver si la zona existe.
            // Si existe no se hace nada
            // Si no existe se debe crear con todos sus datos
            // y almacenar en la correspondencia asociada a su id

            // COMPLETAR

            // Por último, se debe agregar la máquina a esta zona
            // COMPLETAR
        }
    }

    public Set<Zona> getZonas() {
        // COMPLETAR
        return null;
    }

    public Set<Maquina> getMaquinasEnZonaId(int zonaId) {
        // COMPLETAR
        return null;
    }

    public Set<Zona> getZonasConMaquinaId(int mkId) {
        // COMPLETAR
        return null;
    }
}
