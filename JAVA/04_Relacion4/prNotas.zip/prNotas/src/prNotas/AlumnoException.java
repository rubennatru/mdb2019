package prNotas;

public class AlumnoException extends Exception {

    public AlumnoException(){
        super();
    }

    public AlumnoException(String mensaje){
        super(mensaje);
    }
}
