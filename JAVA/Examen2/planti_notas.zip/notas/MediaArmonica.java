package org.uma.mbd.mdNotas.notas;

import java.util.List;
import java.util.OptionalDouble;
import java.util.stream.DoubleStream;

public class MediaArmonica implements CalculoMedia{

	@Override
	public double calcular(List<Alumno> als) throws AlumnoException {
		// COMPLETAR
		return 0;
	}
}
