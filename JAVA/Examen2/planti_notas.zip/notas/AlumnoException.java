package org.uma.mbd.mdNotas.notas;


public class AlumnoException extends Exception {
	public AlumnoException() {
		super();
	}
	public AlumnoException(String msg) {
		super(msg);
	}
}
