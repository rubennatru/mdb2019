package org.uma.mbd.mdNotas.notas;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Asignatura {
	private String nombre;
	private List<Alumno> alumnos;
	private List<String> errores;

	private static final double APROBADO = 5;
	private static final String DNI = "[0-9]{8}[A-Z&&[^IOU]]";

	public Asignatura(String nombreAsignatura) {
		// COMPLETAR
	}

	public void leeDatos(String nombreFichero) throws IOException {
		try (Scanner sc = new Scanner(new File(nombreFichero))){
			// COMPLETAR
		}
	}

	public void leeDatos(String[] datos) {
		for (String dato: datos) {
			// COMPLETAR
        }
	}

	private void stringAAlumno(String linea) {
		try (Scanner sc = new Scanner(linea)) {
			sc.useDelimiter("[;]+");
			sc.useLocale(Locale.ENGLISH);
			// COMPLETAR
//		} catch (AlumnoException e) {
//			// COMPLETAR
		} catch (InputMismatchException e) {
			// COMPLETAR
		} catch (NoSuchElementException e) {
			// COMPLETAR
		}
	}

	public double getCalificacion(Alumno al) throws AlumnoException {
 		// COMPLETAR
 		return 0;
    }

	public List<Alumno> getAlumnos() {
		return alumnos;
	}

	public List<String> getErrores() {
		return errores;
	}

	public Set<String> getNombreAlumnos() {
		// COMPLETAR
		return null;
	}
	
	public double getMedia(CalculoMedia media) throws AlumnoException {
		// COMPLETAR
		return 0;
	}

	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(nombre);
		sb.append(alumnos);
		sb.append(errores);
		return sb.toString();
	}
}
