package org.uma.mbd.mdNotas.notas;

public class Alumno {
	private String nombre;
	private String dni;
	private double nota;
	
	public Alumno(String d, String n, double c) throws AlumnoException {
		//COMPLETAR
	}
	
	public Alumno(String d, String n) throws AlumnoException {
		// COMPLETAR
	}
	
	public boolean equals(Object obj) {
		// COMPLETAR
		return false;
	}
	
	public int hashCode() {
		// COMPLETAR
		return 0;
	}
	
	public String getNombre() {
		return nombre;
	}

	public String getDni() {
		return dni;
	}

	public double getCalificacion() {
		return nota;
	}
	
	public String toString() {
		return nombre + " " + dni;
	}
}
