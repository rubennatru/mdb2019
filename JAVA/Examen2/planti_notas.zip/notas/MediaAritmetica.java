package org.uma.mbd.mdNotas.notas;

import java.util.List;
import java.util.OptionalDouble;

public class MediaAritmetica implements CalculoMedia {

	@Override
	public double calcular(List<Alumno> als) throws AlumnoException{
		// COMPLETAR
		return 0;
	}
}
