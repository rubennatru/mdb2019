package kwic;

public class KWICSustitucion extends KWIC{

    public KWICSustitucion(){
        super();
    }

    @Override
    protected void anyadir(String titulo){
//        new TituloKWICSustitucion(titulo, );
        super.anyadir(titulo);
    }
}
