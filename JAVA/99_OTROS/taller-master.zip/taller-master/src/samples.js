export const samples = {
  "1": {
    "name": "Crown Royal Reserver Dark Roast",
    "price": 1000,
    "image": "crown.jpg",
    "available": "available",
    "description": "Charmingly while prior far one and when vicarious speechlessly thus outside chivalrously inside dug"
  },
  "2": {
    "name": "Fairgrounds Adelaide's Blend",
    "price": 3200,
    "image": "fairgrounds.png",
    "available": "unavailable",
    "description": "Dear hence floppily hyena darn this far jeepers accidentally forward inside a concentrically"
  },
  "3": {
    "name": "Ocean Queen Tea Blend",
    "price": 1200,
    "image": "ocean.jpg",
    "available": "available",
    "description": "Sentimentally some save vacuously underneath ocelot hawk acceptably blandly some because aloofly far"
  },
  "4": {
    "name": "Union Yigarcheffe",
    "price": 1500,
    "image": "union.jpg",
    "available": "available",
    "description": "Much successfully at occasional and winked some darn felt and ouch the and bastard far"
  }
};