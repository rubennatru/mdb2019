package org.uma.mbd.mdLibreriaV3L.libreria;

@FunctionalInterface
public interface OfertaFlex {
    public double getDescuento(Libro libro);
}
