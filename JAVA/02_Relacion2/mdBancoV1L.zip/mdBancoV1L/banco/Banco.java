package org.uma.mbd.mdBancoV1L.banco;

import java.util.Arrays;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;

public class Banco {
    private String nombre;
    private List <Cuenta> cuentas;
    private int snc;
    private static final int PRIMER_NUM_CTA = 1001;

    public Banco(String bco){
        nombre = bco;
        cuentas = new ArrayList<>();
        snc = PRIMER_NUM_CTA;
    }

    public int abrirCuenta(String tit, double cant){
        Cuenta cuenta = new Cuenta(tit, snc, cant);
        snc++;
        return snc-1;
    }

    public int abrirCuenta(String tit){
        Cuenta cuenta = new Cuenta(tit, snc);
        abrirCuenta(cuenta);
        snc++;
        return snc-1;
    }

    public void abrirCuenta(Cuenta cuenta) {
        int i = posicionCuenta(cuenta.getNumCuenta());
        if (i < 0) {
            cuentas.add(cuenta);
        } else {
            throw new RuntimeException("El titular ya existe");
        }
    }

    public void cerrarCuenta(int ncu) {
        int pos = posicionCuenta(ncu);
        if (pos >= 0) {
            cuentas.remove(pos);
        }else{
            throw new RuntimeException("No existe la cuenta que desea cerrar");
        }
    }

    private int posicionCuenta(int ncu){
        int pos = 0;
        while (pos < cuentas.size()
                && !(ncu == cuentas.get(pos).getNumCuenta())) {
            pos++;
        }
        return (pos == cuentas.size()) ? -1 : pos;
    }

    private double consultaSaldo(int ncu){
        int i = posicionCuenta(ncu);
        return(i >= 0) ?  cuentas.get(i).getSaldo() : 0;
    }

    public void ingreso(int ncu, double cant){
        int pos = 0;
        posicionCuenta(ncu);
        if (pos>=0){
            double saldo = cuentas.get(pos).getSaldo() + cant;
            Cuenta cuenta = new Cuenta(cuentas.get(pos).getTitular(), cuentas.get(pos).getNumCuenta(), saldo);
            cuentas.set(pos, cuenta);
        }else{
            throw new RuntimeException("La cuenta donde ingresar dinero no existe");
        }
    }

    public void debito(int ncu, double cant){
        int pos = 0;
        posicionCuenta(ncu);
        if (pos>=0){
            double saldo = cuentas.get(pos).getSaldo() - cant;
            Cuenta cuenta = new Cuenta(cuentas.get(pos).getTitular(), cuentas.get(pos).getNumCuenta(), saldo);
            cuentas.set(pos, cuenta);
        }else{
            throw new RuntimeException("La cuenta para retirar dinero no existe");
        }
    }

    public void transferencia(int ncuOrig, int ncuDest, double cant){
        debito(ncuOrig, cant);
        ingreso(ncuDest, cant);

    }



    @Override
    public String toString() {
        return cuentas.toString();
    }
}
