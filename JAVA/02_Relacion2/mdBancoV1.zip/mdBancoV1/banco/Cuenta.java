package org.uma.mbd.mdBancoV1.banco;

public class Cuenta {
    private int numCuenta;
    private double saldo;
    private String titular;

    public Cuenta(String tit, int nCu){
        titular = tit;
        numCuenta = nCu;
    }

    public Cuenta(String tit, int nCu, double sal){
        titular = tit;
        numCuenta = nCu;
        saldo = sal;
    }

    private void Ingreso(double cant){
        saldo += cant;
    }

    private void debito(double cant) {
        saldo -= cant;
    }

    public int getNumCuenta(){
        return numCuenta;
    }

    public double getSaldo(){
        return saldo;
    }

    public String getTitular(){
        return titular;
    }


    @Override
    public String toString() {
        return "La Cuenta: " + numCuenta + " perteneciente a " + titular +" con Saldo: " + saldo + ")";
    }
}
