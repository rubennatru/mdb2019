package org.uma.mbd.mdBancoV1.banco;

import java.util.Arrays;

public class Banco {
    private String nombre;
    private Cuenta[] cuentas;
    private int ppl;
    private int snc;
    private static int TAM_ARRAY_CTAS = 100;
    private static final int PRIMER_NUM_CTA = 1001;

    public Banco(String bco){
        nombre = bco;
        cuentas = new Cuenta[TAM_ARRAY_CTAS];
        ppl = 0;
        snc = PRIMER_NUM_CTA;
    }

    public Banco(String bco, int n){
        nombre = bco;
        cuentas = new Cuenta[n];
        snc = PRIMER_NUM_CTA;
        ppl = 0;
    }

    public int abrirCuenta(String tit, double cant){
        Cuenta cuenta = new Cuenta(tit, snc, cant);
        aseguraQueCabe();
        cuentas[ppl] = cuenta;
        snc++;
        ppl++;
        return snc-1;
    }

    public int abrirCuenta(String tit){
        Cuenta cuenta = new Cuenta(tit, snc, 0);
        aseguraQueCabe();
        cuentas[ppl] = cuenta;
        snc++;
        ppl++;
        return snc-1;
    }

    public void cerrarCuenta(int ncu) {
        int pos = posicionCuenta(ncu);
        if (pos >= 0) {
            for (int i = pos + 1; i < ppl; i++) {
                cuentas[i - 1] = cuentas[i];
            }
            ppl--;
        }else{
            throw new RuntimeException("No existe la cuenta dada");
        }
    }

    private int posicionCuenta(int ncu){
        int pos = 0;
        while (pos < ppl
                && !(ncu == (cuentas[pos].getNumCuenta()))) {
            pos++;
        }
        return (pos == ppl) ? -1 : pos;
    }

    private double consultaSaldo(int ncu){
        int i = posicionCuenta(ncu);
        return cuentas[i].getSaldo();
    }

    private void aseguraQueCabe() {
        if (ppl == cuentas.length) {
            cuentas = Arrays.copyOf(cuentas, ppl * 2);
        }
    }

    public void ingreso(int ncu, double cant){
        int pos = 0;
        posicionCuenta(ncu);
        Cuenta cuenta = new Cuenta(cuentas[pos].getTitular(), cuentas[pos].getNumCuenta(), cant);
        if (pos>=0){
            double saldo = cuentas[pos].getSaldo() + cant;
            cuentas[pos] = cuenta;
        }else{
            throw new RuntimeException("La cuenta donde ingresar dinero no existe");
        }
    }

    public void debito(int ncu, double cant){
        int pos = 0;
        posicionCuenta(ncu);
        Cuenta cuenta = new Cuenta(cuentas[pos].getTitular(), cuentas[pos].getNumCuenta(), cant);
        if (pos>=0){
            double saldo = cuentas[pos].getSaldo() - cant;
            cuentas[pos] = cuenta;
        }else{
            throw new RuntimeException("La cuenta para retirar dinero no existe");
        }
    }

    public void transferencia(int ncuOrig, int ncuDest, double cant){
        debito(ncuOrig, cant);
        ingreso(ncuDest, cant);

    }



    @Override
    public String toString() {
        return cuentas.toString();
    }
}

