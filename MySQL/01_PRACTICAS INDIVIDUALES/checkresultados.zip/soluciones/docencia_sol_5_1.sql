-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: localhost    Database: docencia
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sol_5_1`
--

DROP TABLE IF EXISTS `sol_5_1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `sol_5_1` (
  `id` varchar(20) NOT NULL,
  `nombre` varchar(20) NOT NULL,
  `apellido1` varchar(20) NOT NULL,
  `apellido2` varchar(20) DEFAULT NULL,
  `codigo` int(3) NOT NULL,
  `asignatura` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sol_5_1`
--

LOCK TABLES `sol_5_1` WRITE;
/*!40000 ALTER TABLE `sol_5_1` DISABLE KEYS */;
INSERT INTO `sol_5_1` VALUES ('F-12-AY-02','Sergio','Gálvez','Rojas',101,'Programación Orientada a Objetos'),('F-12-AY-02','Sergio','Gálvez','Rojas',101,'Programación Orientada a Objetos'),('A-89-CEU-99','Manuel','Enciso','Garcia-Oliveros',112,'Bases de Datos'),('C-34-TU-00','Enrique','Soler','Castillo',112,'Bases de Datos'),('G-34-TEU-96','Ana','Jiménez','Santos',112,'Bases de Datos'),('D-92-PC-92','Maria del Mar','Roldán','García',113,'Calculo Numerico'),('D-92-PC-92','Maria del Mar','Roldán','García',113,'Calculo Numerico'),('C-34-TU-00','Enrique','Soler','Castillo',114,'Teoria de Automatas'),('D-92-PC-92','Maria del Mar','Roldán','García',114,'Teoria de Automatas'),('H-32-TU-99','Miguel','Hermoso','Gala',114,'Teoria de Automatas'),('C-67-CEU-98','Miguel','Ortiz',NULL,116,'Logica Computacional'),('H-32-TU-99','Miguel','Hermoso','Gala',123,'Computación Altas Prestaciones'),('H-77-TU-99','Juana','Hernandez','Lopez',123,'Computación Altas Prestaciones'),('F-12-AY-02','Sergio','Gálvez','Rojas',133,'Ingeniería Web'),('F-12-AY-02','Sergio','Gálvez','Rojas',133,'Ingeniería Web'),('A-89-CEU-99','Manuel','Enciso','Garcia-Oliveros',140,'Prácticas en empresa'),('C-34-TU-00','Enrique','Soler','Castillo',140,'Prácticas en empresa'),('C-34-TU-00','Enrique','Soler','Castillo',140,'Prácticas en empresa'),('C-34-TU-00','Enrique','Soler','Castillo',140,'Prácticas en empresa'),('G-34-TEU-96','Ana','Jiménez','Santos',140,'Prácticas en empresa');
/*!40000 ALTER TABLE `sol_5_1` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-12 14:24:52
