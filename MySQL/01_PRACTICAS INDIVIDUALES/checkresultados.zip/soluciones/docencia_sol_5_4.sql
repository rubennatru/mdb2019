-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: localhost    Database: docencia
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sol_5_4`
--

DROP TABLE IF EXISTS `sol_5_4`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `sol_5_4` (
  `Asignatura 1` varchar(50) NOT NULL,
  `Asignatura 2` varchar(50) NOT NULL,
  `Asignatura 3` varchar(50) NOT NULL,
  `Materia` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sol_5_4`
--

LOCK TABLES `sol_5_4` WRITE;
/*!40000 ALTER TABLE `sol_5_4` DISABLE KEYS */;
INSERT INTO `sol_5_4` VALUES ('Programación Orientada a Objetos','Bases de Datos','Administración de Bases de Datos',1),('Programación Orientada a Objetos','Bases de Datos','Ingeniería Web',1),('Programación Orientada a Objetos','Administración de Bases de Datos','Ingeniería Web',1),('Estadistica','Calculo Numerico','Logica Computacional',4),('Estadistica','Calculo Numerico','Matemática Discreta',4),('Estadistica','Logica Computacional','Matemática Discreta',4),('Bases de Datos','Administración de Bases de Datos','Ingeniería Web',1),('Calculo Numerico','Logica Computacional','Matemática Discreta',4),('Estructura de Computadores','Computación Altas Prestaciones','Dispositivos Electronicos',2);
/*!40000 ALTER TABLE `sol_5_4` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-12 18:21:52
