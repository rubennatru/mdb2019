-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: localhost    Database: docencia
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sol_5_10`
--

DROP TABLE IF EXISTS `sol_5_10`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `sol_5_10` (
  `nombre` varchar(20) NOT NULL,
  `apellido1` varchar(20) DEFAULT NULL,
  `apellido2` varchar(20) DEFAULT NULL,
  `NOMBRE2` varchar(20),
  `APELLIDO2_1` varchar(20) DEFAULT NULL,
  `APELLIDO2_2` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sol_5_10`
--

LOCK TABLES `sol_5_10` WRITE;
/*!40000 ALTER TABLE `sol_5_10` DISABLE KEYS */;
INSERT INTO `sol_5_10` VALUES ('Carlos Alberto','Acosta','Castilla',NULL,NULL,NULL),('Raziz','Afilal',NULL,'Jaime','Villanueva','Arenas'),('David','Alarcon','Garcia y Muntaner','Carlos Alberto','Acosta','Castilla'),('David','Alarcon','Garcia y Muntaner','Nicolas','Bersabe','Alba'),('David','Alarcon','Garcia y Muntaner','Isidro','Villanueva','Fernandez'),('Ana','Alcala','Lopez','MIGUEL ANGEL','ROBLES','DOMINGUEZ'),('Ana','Alcala','Lopez','Hannae','Tourug',NULL),('Arcadio','Armada','Pedrosa',NULL,NULL,NULL),('Nicolas','Bersabe','Alba','Carlos Alberto','Acosta','Castilla'),('Nicolas','Bersabe','Alba','Isidro','Villanueva','Fernandez'),('Salvador','Castillo','Heredia',NULL,NULL,NULL),('Rodrigo','Castro','Picon',NULL,NULL,NULL),('Esther','de Diego','Blasco','Laura','Espinosa','Fuente'),('Esther','de Diego','Blasco','Carlos','Garzon','Trujillano'),('Esther','de Diego','Blasco','Maximo','Leon','Pi'),('Esther','de Diego','Blasco','Sergio','Rivas','Trevijano'),('Laura','Espinosa','Fuente','Sergio','Rivas','Trevijano'),('Manuel','Fernandez','Ortega',NULL,NULL,NULL),('Carlos','Garzon','Trujillano','Laura','Espinosa','Fuente'),('Carlos','Garzon','Trujillano','Maximo','Leon','Pi'),('Carlos','Garzon','Trujillano','Sergio','Rivas','Trevijano'),('Jose','Gil','Hilo','Maria Jose','Lillo','Gamez'),('Jose','Gil','Hilo','Rafael','Villanueva','Galvez'),('MANUEL','GUERRERO','FERNANDEZ',NULL,NULL,NULL),('ALEJANDRO','HINDLEY','FERNANDEZ',NULL,NULL,NULL),('Justo','Iglesias','Aramillo','Manuel','Fernandez','Ortega'),('Gema','Jimenez','Larios','Salvador','Castillo','Heredia'),('Maximo','Leon','Pi','Laura','Espinosa','Fuente'),('Maximo','Leon','Pi','Sergio','Rivas','Trevijano'),('Maria Jose','Lillo','Gamez','Rafael','Villanueva','Galvez'),('IKER','LUQUE','ROBLES',NULL,NULL,NULL),('Samir','Makluofi',NULL,'Salvador','Castillo','Heredia'),('Samir','Makluofi',NULL,'Gema','Jimenez','Larios'),('Samir','Makluofi',NULL,'Elena','Romero','Torao'),('Stephan','Marckus',NULL,'Ana','Alcala','Lopez'),('Stephan','Marckus',NULL,'MIGUEL ANGEL','ROBLES','DOMINGUEZ'),('Stephan','Marckus',NULL,'Hannae','Tourug',NULL),('FRANCISCO JOSE','MARQUEZ','ROCHE',NULL,NULL,NULL),('JOAQUIN','MARQUEZ','RODRIGUEZ',NULL,NULL,NULL),('VICTOR HUGO','MARTIN','FLORIDO',NULL,NULL,NULL),('CARLOS','MARTIN','RUIZ',NULL,NULL,NULL),('PEDRO','MARTIN','RUIZ',NULL,NULL,NULL),('REMEDIOS MARIA','MARTIN','RUIZ',NULL,NULL,NULL),('CARLOS EDUARDO','MARTINEZ','RUIZ',NULL,NULL,NULL),('Victoria','Mayordomo','Toro','Jose','Gil','Hilo'),('Victoria','Mayordomo','Toro','Maria Jose','Lillo','Gamez'),('Victoria','Mayordomo','Toro','Rafael','Villanueva','Galvez'),('TATIANA','MAZGELIS','PEREZ',NULL,NULL,NULL),('AHMED','MEDINA','SALIDO',NULL,NULL,NULL),('Pedro','Melendez','Contado',NULL,NULL,NULL),('Marlon','Mesa','Jimenez','Manuel','Fernandez','Ortega'),('Marlon','Mesa','Jimenez','Justo','Iglesias','Aramillo'),('Marlon','Mesa','Jimenez','Alejandra','Oliveira','Jimenes'),('JORGE','MESTANZA','GARCIA',NULL,NULL,NULL),('CRISTIAN','MIÑAMBRES','SANCHEZ',NULL,NULL,NULL),('Angel','Montero','Puig de Casamayor',NULL,NULL,NULL),('ADRIÁN','MONTIEL',NULL,NULL,NULL,NULL),('FERNANDO','MORALES',NULL,NULL,NULL,NULL),('EDUARDO','MORENO','GARCIA',NULL,NULL,NULL),('JAIRO','MUÑOZ',NULL,NULL,NULL,NULL),('ALVARO','MUÑOZ','GARCIA-FAURE',NULL,NULL,NULL),('Jesus','Neira','Cintado',NULL,NULL,NULL),('IKER','NIETO','SANCHEZ',NULL,NULL,NULL),('Alejandra','Oliveira','Jimenes','Manuel','Fernandez','Ortega'),('Alejandra','Oliveira','Jimenes','Justo','Iglesias','Aramillo'),('CRISTINA','ORTIZ','GOMEZ',NULL,NULL,NULL),('Maria Elena','Ortiz','Montoya','Salvador','Castillo','Heredia'),('Maria Elena','Ortiz','Montoya','Gema','Jimenez','Larios'),('Maria Elena','Ortiz','Montoya','Samir','Makluofi',NULL),('Maria Elena','Ortiz','Montoya','Elena','Romero','Torao'),('ANTONIO','OUAHABI',NULL,NULL,NULL,NULL),('JOSE CARLOS','PALOMINO','ARGUILEA',NULL,NULL,NULL),('CAROLINA','PEREZ','AGUAVIVA',NULL,NULL,NULL),('Zinovia','Petrova',NULL,'Manuel','Fernandez','Ortega'),('Zinovia','Petrova',NULL,'Justo','Iglesias','Aramillo'),('Zinovia','Petrova',NULL,'Marlon','Mesa','Jimenez'),('Zinovia','Petrova',NULL,'Alejandra','Oliveira','Jimenes'),('PABLO','PINTO','ANDRES',NULL,NULL,NULL),('SAMUEL','PRANDI','ARIZA',NULL,NULL,NULL),('CARLOS','RAISSOUNI',NULL,NULL,NULL,NULL),('LUKAS','RAMIRO','CABALLERO',NULL,NULL,NULL),('AITOR','RAMOS','ARAGÓN',NULL,NULL,NULL),('MARIA ARACELI','RANEA','BURGUEÑO',NULL,NULL,NULL),('George','Rice',NULL,NULL,NULL,NULL),('JOSE DAVID','RIOS','CADENA',NULL,NULL,NULL),('Sergio','Rivas','Trevijano',NULL,NULL,NULL),('PABLO','RIVERO','CORTECERO',NULL,NULL,NULL),('MIGUEL ANGEL','ROBLES','DOMINGUEZ','Hannae','Tourug',NULL),('ADRIAN','ROCHE','ECHEVARRI',NULL,NULL,NULL),('ANTONIO','RODRIGUEZ','CANTOS',NULL,NULL,NULL),('DANIEL','RODRIGUEZ','ESCRIBANO',NULL,NULL,NULL),('ANGEL JESUS','ROMERO','CAÑETE',NULL,NULL,NULL),('DANIEL','ROMERO','CARRASCO',NULL,NULL,NULL),('MARIA DE LOS ANGELES','ROMERO','CARRILLO',NULL,NULL,NULL),('Elena','Romero','Torao','Salvador','Castillo','Heredia'),('Elena','Romero','Torao','Gema','Jimenez','Larios'),('ALBERTO JESUS','RUIZ','CARRION',NULL,NULL,NULL),('ALFONSO','RUIZ','ESCUDERO',NULL,NULL,NULL),('SERGIO','RUIZ','ESTEPA',NULL,NULL,NULL),('JUAN','RUIZ','FERNANDEZ',NULL,NULL,NULL),('ADRIAN','RUIZ','FUERTES',NULL,NULL,NULL),('Benjamín','Ruiz','Palacio','Rodrigo','Castro','Picon'),('ALBERTO','SAEZ','CAZORLA','SAMUEL','PRANDI','ARIZA'),('BRIAN','SALIDO','GARCIA',NULL,NULL,NULL),('ISABEL','SANCHEZ','GOMEZ',NULL,NULL,NULL),('MIGUEL ANGEL','SANCHEZ','GOMEZ',NULL,NULL,NULL),('ELOY','SANCHEZ','GONZALEZ',NULL,NULL,NULL),('RUBEN','SANTIAGO','GONZALEZ',NULL,NULL,NULL),('GONZALO','SANTOS','CHICA',NULL,NULL,NULL),('IVAN','SAUZA','CORBACHO',NULL,NULL,NULL),('Enrique','Silva','Cervantes','Salvador','Castillo','Heredia'),('Enrique','Silva','Cervantes','Gema','Jimenez','Larios'),('Enrique','Silva','Cervantes','Samir','Makluofi',NULL),('Enrique','Silva','Cervantes','Maria Elena','Ortiz','Montoya'),('Enrique','Silva','Cervantes','Elena','Romero','Torao'),('BORJA','SILVA','DELGADO',NULL,NULL,NULL),('JOSE ANTONIO','SUAREZ','DIAZ',NULL,NULL,NULL),('RAFAEL','SUAREZ','GONZALEZ',NULL,NULL,NULL),('RUBEN','TORRALVO','HARO',NULL,NULL,NULL),('ASMAE','TORRES',NULL,NULL,NULL,NULL),('Hannae','Tourug',NULL,NULL,NULL,NULL),('FELIPE','TRILLO','JIMENEZ',NULL,NULL,NULL),('ANTONIO JESUS','VALENCIA','JIMENEZ',NULL,NULL,NULL),('MANUEL','VALVERDE','ESTEPA',NULL,NULL,NULL),('CRISTIAN','VAZQUEZ','LEIVA',NULL,NULL,NULL),('ADRIÁN','VELASCO','LLORET',NULL,NULL,NULL),('JUAN DE DIOS','VILLA','ESTRELLA',NULL,NULL,NULL),('Jaime','Villanueva','Arenas',NULL,NULL,NULL),('Isidro','Villanueva','Fernandez','Carlos Alberto','Acosta','Castilla'),('Rafael','Villanueva','Galvez',NULL,NULL,NULL),('Guillermo','Villanueva','Pedraza','Manuel','Fernandez','Ortega'),('Guillermo','Villanueva','Pedraza','Justo','Iglesias','Aramillo'),('Guillermo','Villanueva','Pedraza','Marlon','Mesa','Jimenez'),('Guillermo','Villanueva','Pedraza','Alejandra','Oliveira','Jimenes'),('Guillermo','Villanueva','Pedraza','Zinovia','Petrova',NULL),('ENRIQUE','ZAHTI',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `sol_5_10` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-14 12:57:04
