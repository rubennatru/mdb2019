-- MySQL dump 10.13  Distrib 8.0.12, for Win64 (x86_64)
--
-- Host: localhost    Database: docencia
-- ------------------------------------------------------
-- Server version	8.0.12

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `sol_6_10`
--

DROP TABLE IF EXISTS `sol_6_10`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8mb4 ;
CREATE TABLE `sol_6_10` (
  `profesor1` varchar(62) DEFAULT NULL,
  `profesor2` varchar(62) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sol_6_10`
--

LOCK TABLES `sol_6_10` WRITE;
/*!40000 ALTER TABLE `sol_6_10` DISABLE KEYS */;
INSERT INTO `sol_6_10` VALUES ('Carlos Fernández Croquet','Manuel Enciso Garcia-Oliveros'),('Carlos Fernández Croquet','Enrique Soler Castillo'),('Carlos Fernández Croquet','Miguel Ortiz '),('Carlos Fernández Croquet','Maria del Mar Roldán García'),('Carlos Fernández Croquet','Sergio Gálvez Rojas'),('Carlos Fernández Croquet','Ana Jiménez Santos'),('Carlos Fernández Croquet','Miguel Hermoso Gala'),('Carlos Fernández Croquet','Juana Hernandez Lopez'),('Carlos Fernández Croquet','Michael Brown '),('Carlos Fernández Croquet','Antonio Villanueva Pedraza'),('Manuel Enciso Garcia-Oliveros','Enrique Soler Castillo'),('Manuel Enciso Garcia-Oliveros','Miguel Ortiz '),('Manuel Enciso Garcia-Oliveros','Sergio Gálvez Rojas'),('Manuel Enciso Garcia-Oliveros','Ana Jiménez Santos'),('Manuel Enciso Garcia-Oliveros','Miguel Hermoso Gala'),('Manuel Enciso Garcia-Oliveros','Juana Hernandez Lopez'),('Manuel Enciso Garcia-Oliveros','Michael Brown '),('Manuel Enciso Garcia-Oliveros','Antonio Villanueva Pedraza'),('Enrique Soler Castillo','Maria del Mar Roldán García'),('Enrique Soler Castillo','Sergio Gálvez Rojas'),('Enrique Soler Castillo','Miguel Hermoso Gala'),('Enrique Soler Castillo','Juana Hernandez Lopez'),('Enrique Soler Castillo','Michael Brown '),('Enrique Soler Castillo','Antonio Villanueva Pedraza'),('Miguel Ortiz ','Sergio Gálvez Rojas'),('Miguel Ortiz ','Miguel Hermoso Gala'),('Miguel Ortiz ','Juana Hernandez Lopez'),('Miguel Ortiz ','Michael Brown '),('Miguel Ortiz ','Antonio Villanueva Pedraza'),('Maria del Mar Roldán García','Sergio Gálvez Rojas'),('Maria del Mar Roldán García','Ana Jiménez Santos'),('Maria del Mar Roldán García','Miguel Hermoso Gala'),('Maria del Mar Roldán García','Juana Hernandez Lopez'),('Maria del Mar Roldán García','Michael Brown '),('Maria del Mar Roldán García','Antonio Villanueva Pedraza'),('Sergio Gálvez Rojas','Ana Jiménez Santos'),('Sergio Gálvez Rojas','Miguel Hermoso Gala'),('Sergio Gálvez Rojas','Juana Hernandez Lopez'),('Sergio Gálvez Rojas','Michael Brown '),('Sergio Gálvez Rojas','Antonio Villanueva Pedraza'),('Ana Jiménez Santos','Miguel Hermoso Gala'),('Ana Jiménez Santos','Juana Hernandez Lopez'),('Ana Jiménez Santos','Michael Brown '),('Ana Jiménez Santos','Antonio Villanueva Pedraza'),('Miguel Hermoso Gala','Juana Hernandez Lopez'),('Miguel Hermoso Gala','Michael Brown '),('Miguel Hermoso Gala','Antonio Villanueva Pedraza'),('Juana Hernandez Lopez','Michael Brown '),('Juana Hernandez Lopez','Antonio Villanueva Pedraza'),('Michael Brown ','Antonio Villanueva Pedraza');
/*!40000 ALTER TABLE `sol_6_10` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-11-15 14:28:44
